
const $=s=>document.querySelector(s);
const teams=["Wolves","Aston Villa","Arsenal","Chelsea","Liverpool","Man City","Newcastle","Tottenham"];
const clubStrength={"Wolves":76,"Aston Villa":79,"Arsenal":85,"Chelsea":82,"Liverpool":85,"Man City":86,"Newcastle":81,"Tottenham":80};
let save=JSON.parse(localStorage.getItem("careerXI")||"null");
let page="home";
const persist=()=>localStorage.setItem("careerXI",JSON.stringify(save));
function newSave(p){
 let table=teams.map(t=>({team:t,p:0,w:0,d:0,l:0,gf:0,ga:0,pts:0}));
 return {player:p,season:"2026/27",week:1,club:p.club,trust:55,fitness:100,form:6.8,apps:0,goals:0,assists:0,table,history:[],nextOpponent:teams.find(x=>x!==p.club)||"Aston Villa"};
}
function app(html){$("#app").innerHTML=`<main class="shell">${html}</main>`}
function start(){
 $("#nav").classList.add("hidden");
 app(`<div class="hero"><div class="brand">CAREER<span class="accent">XI</span></div><h1>Your career.<br>Your decisions.</h1><p class="muted">A focused football player-career simulator. Build a player, earn your place and live through a changing football world.</p></div>
 <div class="card"><h3>Player Career</h3><p class="muted">Start as a young player and build your career season by season.</p><button class="btn" onclick="creator()">New Career</button>${save?`<button class="btn secondary" onclick="show('home')">Continue ${save.player.name}</button>`:""}</div>`);
}
function creator(){
 app(`<div class="top"><div class="brand">CAREER<span class="accent">XI</span></div><span class="pill">NEW CAREER</span></div>
 <h2>Create Player</h2><div class="card">
 <label>Name</label><input id="name" value="Cole"/>
 <div class="grid"><div><label>Nationality</label><select id="nat"><option>England</option><option>Scotland</option><option>Wales</option><option>France</option><option>Spain</option><option>Brazil</option></select></div>
 <div><label>Age</label><select id="age">${[16,17,18,19].map(x=>`<option>${x}</option>`).join("")}</select></div></div>
 <div class="grid"><div><label>Height</label><select id="height">${["5'6","5'7","5'8","5'9","5'10","5'11","6'0","6'1","6'2","6'3"].map(x=>`<option>${x}</option>`).join("")}</select></div>
 <div><label>Preferred Foot</label><select id="foot"><option>Right</option><option>Left</option></select></div></div>
 <label>Position</label><select id="pos">${["ST","LW","RW","CAM","CM","CDM","LB","RB","CB","GK"].map(x=>`<option>${x}</option>`).join("")}</select>
 <label>Playstyle</label><select id="style"><option>Inside Forward</option><option>Traditional Winger</option><option>Wide Playmaker</option><option>Advanced Forward</option><option>Poacher</option><option>Box-to-Box</option><option>Ball Winning Midfielder</option><option>Ball Playing Defender</option></select>
 <label>Career Start</label><select id="path"><option>Academy</option><option>Professional</option><option>Custom</option></select>
 <label>Starting Club</label><select id="club">${teams.map(x=>`<option>${x}</option>`).join("")}</select>
 <button class="btn" onclick="createCareer()">Start Career</button></div>`);
}
function createCareer(){
 const p={name:$("#name").value||"Player",nationality:$("#nat").value,age:+$("#age").value,height:$("#height").value,foot:$("#foot").value,pos:$("#pos").value,style:$("#style").value,path:$("#path").value,club:$("#club").value,ovr:64,
 attrs:{Pace:68,Shooting:62,Passing:64,Dribbling:67,Defending:45,Physical:61}};
 save=newSave(p); save.nextOpponent=teams.find(x=>x!==save.club); persist(); show("home");
}
function nav(){
 $("#nav").classList.remove("hidden");
 $("#nav").innerHTML=[["home","Home"],["squad","Career"],["match","Match"],["table","Table"],["history","History"]].map(([p,n])=>`<button class="${page===p?"active":""}" onclick="show('${p}')">${n}</button>`).join("");
}
function show(p){page=p;nav(); if(p==="home")home(); if(p==="squad")career(); if(p==="match")match(); if(p==="table")table(); if(p==="history")history();}
function home(){
 let s=save;
 app(`<div class="top"><div><div class="brand">CAREER<span class="accent">XI</span></div><div class="muted">${s.season} • Week ${s.week}</div></div><span class="pill">${s.club}</span></div>
 <div class="card"><div class="section-title">Next Match</div><div class="fixture"><div class="clubs"><span>${s.club}</span><span class="vs">VS</span><span>${s.nextOpponent}</span></div><p class="muted">League • Saturday 15:00</p><button class="btn" onclick="show('match')">Play Match</button></div></div>
 <div class="grid"><div class="stat"><span class="muted">OVR</span><b>${s.player.ovr}</b></div><div class="stat"><span class="muted">Manager Trust</span><b>${s.trust}</b></div><div class="stat"><span class="muted">Apps</span><b>${s.apps}</b></div><div class="stat"><span class="muted">G/A</span><b>${s.goals}/${s.assists}</b></div></div>
 <div class="card"><h3>${s.player.name}</h3><p>${s.player.pos} • ${s.player.style}</p><div class="progress"><i style="width:${s.fitness}%"></i></div><p class="muted">Fitness ${s.fitness}% • Form ${s.form.toFixed(1)}</p></div>`);
}
function career(){
 let p=save.player;
 app(`<div class="top"><h2>Career</h2><span class="pill">${p.pos}</span></div><div class="card"><h3>${p.name}</h3><p class="muted">${p.age} • ${p.nationality} • ${p.height} • ${p.foot} foot</p><div class="grid">${Object.entries(p.attrs).map(([k,v])=>`<div class="stat"><span class="muted">${k}</span><b>${v}</b></div>`).join("")}</div></div>
 <div class="card"><h3>Development</h3><p class="muted">Training focus</p><select id="training"><option>Balanced</option><option>Pace</option><option>Shooting</option><option>Passing</option><option>Dribbling</option><option>Defending</option><option>Physical</option></select><button class="btn secondary" onclick="train()">Complete Training</button></div>`);
}
function train(){let f=$("#training").value;if(f!=="Balanced"&&save.player.attrs[f]<90)save.player.attrs[f]++;save.fitness=Math.max(80,save.fitness-2);save.trust=Math.min(100,save.trust+1);persist();career();}
let matchState=null;
function match(){
 if(!matchState) matchState={minute:0,home:0,away:0,rating:6.5,events:[],moments:0};
 let m=matchState;
 app(`<div class="top"><h2>Matchday</h2><span class="pill">${m.minute}'</span></div><div class="card fixture"><div class="clubs"><span>${save.club} ${m.home}</span><span class="vs">-</span><span>${m.away} ${save.nextOpponent}</span></div><p class="muted">${save.player.name} • Rating ${m.rating.toFixed(1)}</p></div>
 <div id="moment">${m.minute>=90?endMatchUI():`<button class="btn" onclick="advance()">Continue Match</button>`}</div>
 <div class="card"><h3>Match Events</h3>${m.events.length?m.events.slice().reverse().map(e=>`<div class="event">${e}</div>`).join(""):`<p class="muted">Kick-off awaits.</p>`}</div>`);
}
function advance(){
 let m=matchState;m.minute=Math.min(90,m.minute+Math.floor(6+Math.random()*10));
 if(Math.random()<.28){decision();return}
 if(Math.random()<.20){let us=Math.random()<.52;if(us)m.home++;else m.away++;m.events.push(`${m.minute}' ⚽ ${us?save.club:save.nextOpponent} score.`)}
 match();
}
function decision(){
 let m=matchState, types=[
 {title:"Attacking Third",text:"You receive the ball on the wing.",opts:["Dribble","Cross","Through Ball","Pass"]},
 {title:"Inside the Box",text:"The ball falls to you inside the box.",opts:["Shoot","Pass","Dribble"]},
 {title:"Counter Attack",text:"Your team breaks forward.",opts:["Make Run","Come Short","Through Ball","Pass"]},
 {title:"Attacking Corner",text:"Your teammate is taking the corner.",opts:["Come Short","Edge of Box","Get Forward"]}
 ];
 let d=types[Math.floor(Math.random()*types.length)];
 $("#moment").innerHTML=`<div class="card"><div class="section-title">${m.minute}' • ${d.title}</div><h3>${d.text}</h3>${d.opts.map(o=>`<button class="choice" onclick="choose('${o}')">${o}</button>`).join("")}</div>`;
}
function choose(o){
 let m=matchState;let chance=.48+(save.player.ovr-64)*.008;let success=Math.random()<chance;
 if(o==="Shoot"&&success){m.home++;save.goals++;m.rating+=.9;m.events.push(`${m.minute}' ⚽ ${save.player.name} scores.`)}
 else if((o==="Cross"||o==="Through Ball"||o==="Pass")&&success&&Math.random()<.28){m.home++;save.assists++;m.rating+=.6;m.events.push(`${m.minute}' 🅰 ${save.player.name} creates the goal with a ${o.toLowerCase()}.`)}
 else {m.rating+=success?.15:-.08;m.events.push(`${m.minute}' ${success?"✓":"×"} ${o} — ${success?"successful":"unsuccessful"}.`)}
 m.moments++;match();
}
function endMatchUI(){return `<div class="card"><h3>Full Time</h3><p class="muted">Finish the match to update your career and league table.</p><button class="btn" onclick="finishMatch()">Finish Match</button></div>`}
function finishMatch(){
 let m=matchState; save.apps++; save.form=Math.max(5.5,Math.min(10,m.rating)); save.fitness=Math.max(70,save.fitness-10); save.trust=Math.max(0,Math.min(100,save.trust+(m.rating>=7?2:m.rating<6.3?-2:0)));
 applyResult(save.club,save.nextOpponent,m.home,m.away);
 // simulate other games
 let others=teams.filter(t=>t!==save.club&&t!==save.nextOpponent);
 for(let i=0;i<others.length;i+=2){let a=others[i],b=others[i+1];let ga=Math.max(0,Math.round(Math.random()*3+(clubStrength[a]-clubStrength[b])/15));let gb=Math.max(0,Math.round(Math.random()*3+(clubStrength[b]-clubStrength[a])/15));applyResult(a,b,ga,gb)}
 save.history.push({week:save.week,opp:save.nextOpponent,score:`${m.home}-${m.away}`,rating:m.rating.toFixed(1)});
 save.week++; let candidates=teams.filter(t=>t!==save.club);save.nextOpponent=candidates[(save.week-1)%candidates.length]; matchState=null;persist();show("home");
}
function applyResult(a,b,ga,gb){let A=save.table.find(x=>x.team===a),B=save.table.find(x=>x.team===b);A.p++;B.p++;A.gf+=ga;A.ga+=gb;B.gf+=gb;B.ga+=ga;if(ga>gb){A.w++;B.l++;A.pts+=3}else if(gb>ga){B.w++;A.l++;B.pts+=3}else{A.d++;B.d++;A.pts++;B.pts++}}
function sortedTable(){return [...save.table].sort((a,b)=>b.pts-a.pts||((b.gf-b.ga)-(a.gf-a.ga))||b.gf-a.gf)}
function table(){
 app(`<h2>League Table</h2><div class="card"><table><thead><tr><th>#</th><th>Club</th><th>P</th><th>GD</th><th>Pts</th></tr></thead><tbody>${sortedTable().map((t,i)=>`<tr><td>${i+1}</td><td class="${t.team===save.club?"good":""}">${t.team}</td><td>${t.p}</td><td>${t.gf-t.ga}</td><td><b>${t.pts}</b></td></tr>`).join("")}</tbody></table></div>`);
}
function history(){
 app(`<h2>Career History</h2><div class="card"><h3>${save.season}</h3>${save.history.length?save.history.map(x=>`<div class="event">W${x.week} • ${save.club} ${x.score} ${x.opp}<br><span class="muted">Rating ${x.rating}</span></div>`).join(""):`<p class="muted">No matches played yet.</p>`}</div><button class="btn secondary" onclick="if(confirm('Delete this career?')){localStorage.removeItem('careerXI');save=null;start()}">Delete Career</button>`);
}
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
start();
